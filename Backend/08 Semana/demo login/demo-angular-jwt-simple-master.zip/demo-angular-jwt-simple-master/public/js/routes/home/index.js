angular.module('mainApp')
	.config(function ($routeProvider) {

	  $routeProvider
			.when('/', {
			  templateUrl: '/js/routes/home/template.html'
		})

	})
